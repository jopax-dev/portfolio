# Welcome
Hola, bienvenidos al proyecto de mi portfolio.

Es un proyecto bastante básico con una estructura de landing, proyectos, contacto, about y un pequeño blog hecho a mano.
Además contara con un backoffice desde el que poder gestionar el contenido.

## Roadmap
- Secciones básicas ✅ 
- Backoffice
- Blog

## Licencia
El proyecto disponible bajo la licencia ISC. Puedes usar, copiar, modificar y distribuir el código, 
siempre y cuando incluyas una atribución al autor original en los créditos de tu proyecto.